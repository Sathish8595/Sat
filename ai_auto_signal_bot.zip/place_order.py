# Function to place order via Zerodha

def place_order(symbol, action):
    return f'{action} order placed for {symbol}'