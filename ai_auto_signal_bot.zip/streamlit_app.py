# Streamlit UI for AI Auto Signal Bot
import streamlit as st

st.title('AI Auto Signal Bot')
st.write('Signal system for NIFTY / SENSEX / RELIANCE')